package com.mzdigital.mahfazati

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*

val Context.ds by preferencesDataStore("settings")
private val NAME = stringPreferencesKey("name")

val EXP = listOf("الطعام والشراب", "النقل والمواصلات", "التسوق", "الفواتير", "الإنترنت والاتصالات", "الصحة", "التعليم", "المنزل", "الترفيه", "أخرى")
val INC = listOf("الراتب", "العمل الإضافي", "التجارة", "الهدايا", "المشاريع", "أخرى")

fun Long.fmt(): String = NumberFormat.getInstance(Locale.US).format(this) + " د.ع"

fun monthStart(off: Int = 0): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.MONTH, off)
    return c.timeInMillis
}

fun List<Tx>.spent(from: Long, to: Long = Long.MAX_VALUE, cat: String? = null): Long =
    filter { it.type == "EXPENSE" && it.date >= from && it.date < to && (cat == null || it.category == cat) }.sumOf { it.amount }

fun bal(a: Account, t: List<Tx>): Long {
    var b = a.initial
    for (x in t) {
        when (x.type) {
            "INCOME" -> if (x.accountId == a.id) b += x.amount
            "EXPENSE" -> if (x.accountId == a.id) b -= x.amount
            "TRANSFER" -> { if (x.accountId == a.id) b -= x.amount; if (x.toAccountId == a.id) b += x.amount }
        }
    }
    return b
}

class VM(private val app: Application) : AndroidViewModel(app) {
    private val db = Room.databaseBuilder(app, DB::class.java, "mahfazati.db").build()
    private val d = db.dao()
    private fun <T> Flow<T>.st(init: T) = stateIn(viewModelScope, SharingStarted.Eagerly, init)

    val accounts = d.accounts().st(emptyList())
    val txs = d.txs().st(emptyList())
    val debts = d.debts().st(emptyList())
    val goals = d.goals().st(emptyList())
    val budgets = d.budgets().st(emptyList())
    val name: StateFlow<String?> = app.ds.data.map { it[NAME] ?: "" }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    var hidden by mutableStateOf(false)
    fun money(v: Long) = if (hidden) "••••••" else v.fmt()

    private fun io(b: suspend () -> Unit) { viewModelScope.launch(Dispatchers.IO) { b() } }

    fun setup(n: String) = io { app.ds.edit { it[NAME] = n }; if (d.accountCount() == 0) d.addAccount(Account(name = "نقداً")) }
    fun rename(n: String) = io { app.ds.edit { it[NAME] = n } }
    fun addTx(t: Tx) = io { d.addTx(t) }
    fun delTx(t: Tx) = io { d.delTx(t) }
    fun addAccount(a: Account) = io { d.addAccount(a) }
    fun delAccount(a: Account) = io { if (txs.value.none { it.accountId == a.id || it.toAccountId == a.id } && accounts.value.size > 1) d.delAccount(a) }
    fun addDebt(x: Debt) = io { d.addDebt(x) }
    fun delDebt(x: Debt) = io { d.delDebt(x) }
    fun pay(x: Debt, amt: Long) = io { d.upDebt(x.copy(paid = minOf(x.amount, x.paid + amt))) }
    fun addGoal(g: Goal) = io { d.addGoal(g) }
    fun delGoal(g: Goal) = io { d.delGoal(g) }
    fun saveGoal(g: Goal, amt: Long) = io { d.upGoal(g.copy(saved = g.saved + amt)) }
    fun setBudget(cat: String, cap: Long) = io { if (cap <= 0) d.delBudget(Budget(cat, 0)) else d.setBudget(Budget(cat, cap)) }
    fun wipe() = io { db.clearAllTables(); app.ds.edit { it.clear() } }
}
