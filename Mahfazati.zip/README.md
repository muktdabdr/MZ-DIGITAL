# محفظتي | Mahfazati
Developed by M.Z DIGITAL. Kotlin + Jetpack Compose + Room + DataStore (MVVM).
Build: `gradle assembleDebug` (JDK 17). APK: app/build/outputs/apk/debug/app-debug.apk
